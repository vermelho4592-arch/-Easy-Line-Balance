Easy Line Balance v0.2.0
- Multi-Line (each line has its own Summary, Takt Time and up to 40 OP)
- Up to 20 work steps per OP
- VA / NNVA / NVA classification with shade families
- VA/NNVA/NVA percentage on Line Summary and each OP page
- Yamazumi chart and touch drag between OPs within a line
- Fixed debug signing key included for repeatable demo updates
