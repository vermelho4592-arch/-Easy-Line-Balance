# Easy Line Balance

Android demo for mobile use.

## Current demo scope
- Summary dashboard with Yamazumi chart
- Takt Time input
- Up to 40 OP sheets
- One OP per sheet
- Up to 20 work steps per OP
- Work step name + Cycle Time editing on each OP sheet
- Efficiency = Total Cycle Time / Takt Time × 100
- Drag/drop work step between OPs from Summary
- Tap a work-step block as a mobile fallback to choose destination OP
- Local on-device storage

## Build APK with GitHub Actions
Push the project to GitHub. The included workflow builds `app-debug.apk` and exposes it as an Actions artifact.
