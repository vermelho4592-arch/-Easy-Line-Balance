# Demo app: no custom rules required.
